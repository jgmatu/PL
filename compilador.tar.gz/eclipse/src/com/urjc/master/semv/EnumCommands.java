package com.urjc.master.semv;

public enum EnumCommands {
    FUNCTION, PARAMETERS, VARIABLE
};
