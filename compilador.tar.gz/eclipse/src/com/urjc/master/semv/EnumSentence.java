package com.urjc.master.semv;

public enum EnumSentence {
	RETURN, WHILE, IF, FOR, ELSE;
}
