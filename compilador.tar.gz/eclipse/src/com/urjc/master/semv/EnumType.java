package com.urjc.master.semv;

public enum EnumType {
    FLOAT, VOID, INT, ERROR
};

