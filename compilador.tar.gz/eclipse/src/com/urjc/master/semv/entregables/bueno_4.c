
void write(int n) {
    int i;
    int len;

    len = 0;
    for (i = 0; i < n; i = i + 1) {
		len = n + 1;
    }
}

int main(int argc) {
    int n;
    
    n = 128;
    write(numb);    
    
    return 0;
}
