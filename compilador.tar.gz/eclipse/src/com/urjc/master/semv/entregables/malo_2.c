int main(int a)
{
    a = a + 1.0;
}

int main (float hola, int argc)
{
	int a;
	a = 3;	
	if (a < 3) then {
		a = a + 3;
	} else {
		a = 0;
	}
	
	for (a = 0; a < 3; a = a + 1) {
		a = a * 10;
	}
}

