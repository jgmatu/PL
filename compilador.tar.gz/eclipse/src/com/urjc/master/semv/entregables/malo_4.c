void write(int n) {
    int ix;
    int leng;

    len = 0;
    for (i = 0; i < n; i = i + 1) {
		len = n + 1;
    }
}

void bla() {
    float a;

    a = a + 1.0;
    a = 1;
    a = b;    
}

int main(int argc) {
    int n;
    
    n = 128;
    writes(numb);   
    bla();

    return 0;
}
